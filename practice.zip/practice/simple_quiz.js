
    
    const quizdata=[
    {
        question: "What is the captial of France",
        option:["Paris", "London", "Berlin", "Madrid"],
        correct:0
    },
    {
        question: "What is the largest planet in our solar system?",
        option:["Earth", "Mars", "Jupiter", "Saturn"],
        correct:2
    },
    {
        question: "What is the chemical symbol for water?",
        option:["H2O", "CO2", "O2", "NaCl"],
        correct:0
    },
    {
        question: "Who wrote 'To Kill a Mockingbird'?",
        option:["Harper Lee", "Mark Twain", "Ernest Hemingway", "F. Scott Fitzgerald"],
        correct:0
    },
    {
        question: "What is the capital of Japan?",
        option:["Tokyo", "Seoul", "Beijing", "Bangkok"],
        correct:0
    }
]

function questionspage(){
    document.getElementById("start-container").style.display= "none";
    document.getElementById("question-container").style.display= "block";
    loadquestion();
}

function loadquestion(){
    let questiontext = document.getElementById("question-text");
    let options = document.getElementById("option-container");

    let currentQuestion = 0;
    let result  = 0;

    questiontext.innerText = quizdata[currentQuestion].question;

    options.innerHTML="";

    quizdata[currentQuestion].option.forEach((eachoption,index)=>{
        let label = document.createElement('label');
        label.innerText=eachoption;
        label.classList.add('option-created');
        label.onclick=()=>checkanswer(label,index);
        options.appendChild(label);
    })

    function checkanswer(label,index){
        if(index==quizdata[currentQuestion].correct){
            label.style.color='green';
        }else{
            let correctanswer=quizdata[currentQuestion].option[correct];
            label.style.color='red';
        }

    }
}