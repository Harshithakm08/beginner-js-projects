const inputvalue=document.getElementById("display");
//console.log(inputvalue);

 function appenvalue(value) {
    inputvalue.value += value;
 }

 function cleardisplay(){
    inputvalue.value = "";
}

function calculate() {
    try{
        inputvalue.value = eval(inputvalue.value);
    }
    catch(error){
        alert("Invalid Expression");
        inputvalue.value = "";
    }
}
function eraseone(){
    inputvalue.value = inputvalue.value.slice(0, -1);
}