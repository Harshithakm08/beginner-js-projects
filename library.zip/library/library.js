const home = document.getElementById('container');
const admin = document.getElementById('admin-container');
const user = document.getElementById('user-container');

if (home && admin && user) {
    // Set default state: Show home, hide admin and user
    home.style.display = 'block';
    admin.style.display = 'none';
    user.style.display = 'none';

    function adminpage() {
        home.style.display = 'none';
        user.style.display = 'none';
        admin.style.display = 'block'; // Show admin section
    }

    function userpage() {
        home.style.display = 'none';
        admin.style.display = 'none';
        user.style.display = 'block'; // Show user section
    }
}