
function current_time(){
    time = setInterval(()=>{
        date_time=new Date();
        let hours = date_time.getHours().toString();
        let min = date_time.getMinutes().toString();
        let sec= date_time.getSeconds().toString();
        document.getElementById('time').textContent = `${hours}:${min}:${sec}`;
    }, 1000)
    clearInterval(time);
};
current_time();

function stopwatch_page(){
    document.getElementById('stopwatch').style.display = 'block';
    document.getElementById('digitalclock').style.display = 'none';
}

let h=0;
let m=0;
let s=0;
let t=0;
let running=false;

function start(){
    if(!running){
        running=true;
    t= setInterval(()=>{
        s=s+1;
        if(s==60){
            m=m+1;
            s=0;
        }else if(s==60 && m==60){
            h=h+1;
            s,m=0;
        }
        document.getElementById('runningtime').textContent=`${h.toString()}:${m.toString()}:${s.toString()}`
    },1000)
}
}

function stop(){
    clearInterval(t);
    running=false;
}

function reset(){
    document.getElementById('runningtime').textContent=`00:00:00`
    running=false;
    h,m,s=0;
}