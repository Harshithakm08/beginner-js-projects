class MenuItems {
    constructor(name, image, price) {
        this.name = name;
        this.image = image;
        this.price = price;
    }
}

let items = [
    new MenuItems('pizza', 'images/pizza.jpg', 100),
    new MenuItems('burger', 'images/burger.jpg', 90),
    new MenuItems('cola', 'images/cola.jpg', 50)
];

const mainmenu = document.getElementById('menu');

// Load existing cart items from localStorage
let cartItems = JSON.parse(localStorage.getItem("cart")) || [];

// Function to render menu items
items.forEach(item => {
    let container = document.createElement('div');
    container.classList.add('item');

    let imge = document.createElement('img');
    imge.src = item.image;
    imge.alt = item.name;

    let title = document.createElement('h2');
    title.textContent = item.name;

    let cost = document.createElement('h2');
    cost.textContent = `₹${item.price}`;

    // Quantity display
    let quantityDisplay = document.createElement('span');
    quantityDisplay.className = "quantity-display";
    const existingItem = cartItems.find(cartItem => cartItem.name === item.name);
    quantityDisplay.textContent = existingItem ? existingItem.quantity : 0;

    // Add button
    let addButton = document.createElement('button');
    addButton.className = "add-btn";
    addButton.textContent = "+";
    addButton.onclick = () => {
        addTocart(item, quantityDisplay);
    };

    // Subtract button
    let subtractButton = document.createElement('button');
    subtractButton.className = "subtract-btn";
    subtractButton.textContent = "-";
    subtractButton.onclick = () => {
        removeFromCart(item, quantityDisplay);
    };

    container.appendChild(imge);
    container.appendChild(title);
    container.appendChild(cost);
    container.appendChild(subtractButton);
    container.appendChild(quantityDisplay);
    container.appendChild(addButton);

    mainmenu.appendChild(container);
});

// Function to add an item to the cart
function addTocart(item, quantityDisplay) {
    const existingItem = cartItems.find(cartItem => cartItem.name === item.name);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cartItems.push({ ...item, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cartItems));
    quantityDisplay.textContent = existingItem ? existingItem.quantity : 1;
}

// Function to remove an item from the cart
function removeFromCart(item, quantityDisplay) {
    const existingItem = cartItems.find(cartItem => cartItem.name === item.name);
    if (existingItem) {
        existingItem.quantity -= 1;
        if (existingItem.quantity <= 0) {
            cartItems = cartItems.filter(cartItem => cartItem.name !== item.name);
        }
    }
    localStorage.setItem("cart", JSON.stringify(cartItems));
    quantityDisplay.textContent = existingItem ? existingItem.quantity : 0;
}