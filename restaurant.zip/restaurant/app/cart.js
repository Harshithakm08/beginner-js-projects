// Load cart items from localStorage
let cartItems = JSON.parse(localStorage.getItem("cart")) || [];

// Get references to DOM elements
const cartList = document.getElementById("cartList");
const totalElement = document.getElementById("total");
const clearCartButton = document.getElementById("clearCart");

// Function to render the cart
function renderCart() {
  cartList.innerHTML = ""; // Clear the cart list

  cartItems.forEach((item, index) => {
    const li = document.createElement("li");
    li.className = "cart-item";
    li.textContent = `${item.name} x ${item.quantity} = ₹${item.price * item.quantity}`;

    const removeButton = document.createElement("button");
    removeButton.textContent = "❌";
    removeButton.className = "remove-btn";
    removeButton.onclick = () => {
      removeItem(index);
    };

    li.appendChild(removeButton);
    cartList.appendChild(li);
  });

  // Update the total price
  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  totalElement.textContent = total.toFixed(2);
}

// Function to remove an item from the cart
function removeItem(index) {
  cartItems.splice(index, 1); // Remove the item from the array
  localStorage.setItem("cart", JSON.stringify(cartItems)); // Update localStorage
  renderCart(); // Re-render the cart
}

// Function to clear the cart
clearCartButton.onclick = () => {
  cartItems = []; // Clear the cart array
  localStorage.setItem("cart", JSON.stringify(cartItems)); // Update localStorage
  renderCart(); // Re-render the cart
};

// Initial render
renderCart();