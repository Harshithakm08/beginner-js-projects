const rollsound = new Audio('dice-142528.mp3');

function roledice(){

    rollsound.play();

    const dicenumber=Math.floor(Math.random()*6)+1;
    const diceimage = `dice_image/icons8-dice-${dicenumber}-50.png`;
    const diceimg = document.getElementById('dice-img');

    diceimg.classList.add('shake');

    setTimeout(() => {
        diceimg.setAttribute('src', diceimage);
        diceimg.classList.remove('shake');
    }, 1000);
}